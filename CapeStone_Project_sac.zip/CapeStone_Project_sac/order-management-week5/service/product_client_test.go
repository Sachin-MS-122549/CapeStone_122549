package service

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"github.com/sony/gobreaker"
)

func TestHTTPProductClientRetriesWithExponentialBackoff(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		if requests.Add(1) <= 2 {
			http.Error(w, "temporarily unavailable", http.StatusServiceUnavailable)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"price":12.5}`))
	}))
	defer server.Close()

	client := NewHTTPProductClient(server.URL, time.Second, 2)
	start := time.Now()
	price, err := client.Price(context.Background(), 501)
	elapsed := time.Since(start)
	if err != nil {
		t.Fatalf("Price returned unexpected error: %v", err)
	}
	if price != 12.5 {
		t.Fatalf("expected price 12.5, got %v", price)
	}
	if got := requests.Load(); got != 3 {
		t.Fatalf("expected 3 requests (initial plus 2 retries), got %d", got)
	}
	if elapsed < 290*time.Millisecond {
		t.Fatalf("expected 100ms and 200ms backoff, elapsed %s", elapsed)
	}
}

func TestHTTPProductClientDoesNotRetryClientErrors(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		http.Error(w, "not found", http.StatusNotFound)
	}))
	defer server.Close()

	client := NewHTTPProductClient(server.URL, time.Second, 3)
	_, err := client.Price(context.Background(), 404)
	if !errors.Is(err, ErrProductUnavailable) {
		t.Fatalf("expected controlled product error, got %v", err)
	}
	if got := requests.Load(); got != 1 {
		t.Fatalf("expected 1 request for a non-retryable status, got %d", got)
	}
}

func TestHTTPProductClientEnforcesTimeout(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		<-r.Context().Done()
	}))
	defer server.Close()

	client := NewHTTPProductClient(server.URL, 30*time.Millisecond, 0)
	_, err := client.Price(context.Background(), 501)
	if !errors.Is(err, ErrProductUnavailable) {
		t.Fatalf("expected controlled product error, got %v", err)
	}
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("expected timeout to be preserved in error, got %v", err)
	}
}

func TestHTTPProductClientCancellationStopsRetryBackoff(t *testing.T) {
	var requests atomic.Int32
	firstRequest := make(chan struct{}, 1)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		firstRequest <- struct{}{}
		http.Error(w, "temporarily unavailable", http.StatusServiceUnavailable)
	}))
	defer server.Close()

	client := NewHTTPProductClient(server.URL, time.Second, 5)
	ctx, cancel := context.WithCancel(context.Background())
	result := make(chan error, 1)
	go func() {
		_, err := client.Price(ctx, 501)
		result <- err
	}()

	<-firstRequest
	time.Sleep(20 * time.Millisecond)
	cancel()

	select {
	case err := <-result:
		if !errors.Is(err, ErrProductUnavailable) || !errors.Is(err, context.Canceled) {
			t.Fatalf("expected controlled cancellation error, got %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("Price did not stop after the request context was canceled")
	}
	if got := requests.Load(); got != 1 {
		t.Fatalf("expected cancellation to prevent retries, got %d requests", got)
	}
}

func TestHTTPProductClientOpensCircuitAfterRepeatedFailures(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		http.Error(w, "temporarily unavailable", http.StatusServiceUnavailable)
	}))
	defer server.Close()

	client := NewHTTPProductClient(server.URL, time.Second, 0)
	for attempt := 0; attempt < circuitFailureLimit; attempt++ {
		_, err := client.Price(context.Background(), 501)
		if !errors.Is(err, ErrProductUnavailable) {
			t.Fatalf("attempt %d: expected controlled product error, got %v", attempt+1, err)
		}
	}

	_, err := client.Price(context.Background(), 501)
	if !errors.Is(err, ErrProductUnavailable) || !errors.Is(err, gobreaker.ErrOpenState) {
		t.Fatalf("expected controlled circuit-open error, got %v", err)
	}
	if got := requests.Load(); got != int32(circuitFailureLimit) {
		t.Fatalf("expected open circuit to prevent another request, got %d requests", got)
	}
}

func TestHTTPProductClientBoundsRetryConfiguration(t *testing.T) {
	if got := NewHTTPProductClient("http://localhost", time.Second, maxProductRetries+100).retries; got != maxProductRetries {
		t.Fatalf("expected retries capped at %d, got %d", maxProductRetries, got)
	}
	if got := NewHTTPProductClient("http://localhost", time.Second, -1).retries; got != 0 {
		t.Fatalf("expected negative retries clamped to 0, got %d", got)
	}
	if got := NewHTTPProductClient("http://localhost", 0, 0).timeout; got != defaultProductTimeout {
		t.Fatalf("expected default timeout %s, got %s", defaultProductTimeout, got)
	}
}
