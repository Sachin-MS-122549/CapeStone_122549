package config

import (
	"strings"
	"testing"
)

func TestProductionRequiresAPIKey(t *testing.T) {
	t.Setenv("APP_ENV", "production")
	t.Setenv("DB_HOST", "database.example")
	t.Setenv("API_KEY", "")

	_, err := Load()
	if err == nil || !strings.Contains(err.Error(), "API_KEY is required") {
		t.Fatalf("expected production API_KEY configuration error, got %v", err)
	}
}
