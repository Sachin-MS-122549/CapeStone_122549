package repository

import (
	"context"
	"errors"
	"sort"
	"sync"
	"time"

	"order-management/model"
	"order-management/observability"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

var ErrNotFound = errors.New("order not found")

type OrderRepository interface {
	Create(context.Context, model.Order) (model.Order, error)
	Get(context.Context, int64) (model.Order, error)
	List(context.Context, int, int) ([]model.Order, error)
	UpdateStatus(context.Context, int64, model.OrderStatus) (model.Order, error)
	Ping(context.Context) error
}

type PostgresRepository struct{ db *pgxpool.Pool }

func NewPostgresRepository(db *pgxpool.Pool) *PostgresRepository { return &PostgresRepository{db: db} }
func (r *PostgresRepository) Ping(ctx context.Context) error {
	observability.Trace(ctx, "repository", "ping")
	observability.Trace(ctx, "postgres", "ping")
	err := r.db.Ping(ctx)
	if err != nil {
		observability.RecordDatabaseError()
	}
	return err
}
func (r *PostgresRepository) Create(ctx context.Context, o model.Order) (model.Order, error) {
	observability.Trace(ctx, "repository", "create_order")
	observability.Trace(ctx, "postgres", "insert_order")
	err := r.db.QueryRow(ctx, `INSERT INTO orders(customer_id,product_id,quantity,unit_price,total_amount,status) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,created_at,updated_at`,
		o.CustomerID, o.ProductID, o.Quantity, o.UnitPrice, o.TotalAmount, o.Status).Scan(&o.ID, &o.CreatedAt, &o.UpdatedAt)
	if err != nil {
		observability.RecordDatabaseError()
	}
	return o, err
}

const orderColumns = `id,customer_id,product_id,quantity,unit_price,total_amount,status,created_at,updated_at`

func scanOrder(row interface{ Scan(...any) error }) (model.Order, error) {
	var o model.Order
	err := row.Scan(&o.ID, &o.CustomerID, &o.ProductID, &o.Quantity, &o.UnitPrice, &o.TotalAmount, &o.Status, &o.CreatedAt, &o.UpdatedAt)
	return o, err
}
func (r *PostgresRepository) Get(ctx context.Context, id int64) (model.Order, error) {
	observability.Trace(ctx, "repository", "get_order")
	observability.Trace(ctx, "postgres", "select_order")
	o, err := scanOrder(r.db.QueryRow(ctx, `SELECT `+orderColumns+` FROM orders WHERE id=$1`, id))
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return o, ErrNotFound
		}
		observability.RecordDatabaseError()
		return o, err
	}
	return o, nil
}
func (r *PostgresRepository) List(ctx context.Context, limit, offset int) ([]model.Order, error) {
	observability.Trace(ctx, "repository", "list_orders")
	observability.Trace(ctx, "postgres", "select_orders")
	rows, err := r.db.Query(ctx, `SELECT `+orderColumns+` FROM orders ORDER BY id DESC LIMIT $1 OFFSET $2`, limit, offset)
	if err != nil {
		observability.RecordDatabaseError()
		return nil, err
	}
	defer rows.Close()
	out := make([]model.Order, 0)
	for rows.Next() {
		o, e := scanOrder(rows)
		if e != nil {
			observability.RecordDatabaseError()
			return nil, e
		}
		out = append(out, o)
	}
	err = rows.Err()
	if err != nil {
		observability.RecordDatabaseError()
	}
	return out, err
}
func (r *PostgresRepository) UpdateStatus(ctx context.Context, id int64, s model.OrderStatus) (model.Order, error) {
	observability.Trace(ctx, "repository", "update_order_status")
	observability.Trace(ctx, "postgres", "update_order_status")
	o, err := scanOrder(r.db.QueryRow(ctx, `UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING `+orderColumns, s, id))
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return o, ErrNotFound
		}
		observability.RecordDatabaseError()
		return o, err
	}
	return o, nil
}

// MemoryRepository makes the project usable locally without PostgreSQL. Use PostgreSQL for persistence.
type MemoryRepository struct {
	mu     sync.RWMutex
	orders map[int64]model.Order
	nextID int64
}

func NewMemoryRepository() *MemoryRepository {
	return &MemoryRepository{orders: map[int64]model.Order{}, nextID: 1}
}
func (r *MemoryRepository) Ping(ctx context.Context) error {
	observability.Trace(ctx, "repository", "ping")
	return nil
}
func (r *MemoryRepository) Create(ctx context.Context, o model.Order) (model.Order, error) {
	observability.Trace(ctx, "repository", "create_order")
	r.mu.Lock()
	defer r.mu.Unlock()
	now := time.Now().UTC()
	o.ID = r.nextID
	r.nextID++
	o.CreatedAt = now
	o.UpdatedAt = now
	r.orders[o.ID] = o
	return o, nil
}
func (r *MemoryRepository) Get(ctx context.Context, id int64) (model.Order, error) {
	observability.Trace(ctx, "repository", "get_order")
	r.mu.RLock()
	defer r.mu.RUnlock()
	o, ok := r.orders[id]
	if !ok {
		return o, ErrNotFound
	}
	return o, nil
}
func (r *MemoryRepository) List(ctx context.Context, limit, offset int) ([]model.Order, error) {
	observability.Trace(ctx, "repository", "list_orders")
	r.mu.RLock()
	defer r.mu.RUnlock()
	ids := make([]int64, 0, len(r.orders))
	for id := range r.orders {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] > ids[j] })
	out := make([]model.Order, 0)
	for i := offset; i < len(ids) && len(out) < limit; i++ {
		out = append(out, r.orders[ids[i]])
	}
	return out, nil
}
func (r *MemoryRepository) UpdateStatus(ctx context.Context, id int64, s model.OrderStatus) (model.Order, error) {
	observability.Trace(ctx, "repository", "update_order_status")
	r.mu.Lock()
	defer r.mu.Unlock()
	o, ok := r.orders[id]
	if !ok {
		return o, ErrNotFound
	}
	o.Status = s
	o.UpdatedAt = time.Now().UTC()
	r.orders[id] = o
	return o, nil
}
