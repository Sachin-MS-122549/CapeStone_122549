# Order Management API

A Go-based order management service with REST, GraphQL, database persistence, and lightweight Prometheus-style metrics compatible with local development environments.

## Features

- Create, list, fetch, and update order status
- PostgreSQL support with in-memory fallback for local testing
- Health endpoints for liveness and readiness
- Request ID, recovery, API key, and security headers middleware
- Lightweight metrics endpoint at `/metrics` in a Prometheus-compatible format
- GraphQL endpoint at `/graphql`

## Run locally

1. Copy `.env.example` to `.env` and adjust values if needed.
2. Start PostgreSQL with Docker Compose:
   ```bash
   docker compose up -d postgres
   ```
3. Run the API:
   ```bash
   go run .
   ```

## Order API

The API base URL is `http://localhost:8080`. Its order operations are:

- `POST /api/v1/orders` — create an order with `customerId`, `productId`, and `quantity`.
- `GET /api/v1/orders/{id}` — retrieve one order.
- `GET /api/v1/orders` — list orders; optional `limit` and `offset` query parameters support pagination.
- `PUT /api/v1/orders/{id}/status` — update an order status with a JSON body such as `{"status":"CONFIRMED"}`. `PATCH` is also supported for compatibility.

Creating an order requires the product service configured by `PRODUCT_SERVICE_URL` to return a positive product price.

## Product service resilience

The order service calls `GET {PRODUCT_SERVICE_URL}/products/{productId}` with a per-attempt timeout. `PRODUCT_TIMEOUT_MS` defaults to 2000 ms when unset or non-positive. `PRODUCT_RETRIES` is the number of retries after the first attempt; it is bounded from 0 to 5 (the example uses 2). Retries use exponential delays starting at 100 ms (100 ms, 200 ms, 400 ms, and so on), and stop immediately when the request context is canceled. HTTP 429 and 5xx responses and transport failures are retried; other 4xx responses are not.

The circuit breaker opens after 5 consecutive failed product lookups, rejects calls for 15 seconds, then allows a single half-open probe. Failures return a controlled `product service unavailable` error (HTTP 502 at the REST API); timeout and cancellation causes remain available for internal error inspection.

## Security

- In production, set `API_KEY` to a strong secret (at least 32 characters). The application refuses to start without it. Send it on REST and GraphQL requests using the `X-API-Key` header. The health and metrics endpoints remain unauthenticated.
- This API key is shared authentication, not per-user identity or customer-level authorization. Do not expose the service to untrusted users if you need per-customer order access controls.
- Keep real credentials in the ignored `.env` file or a deployment secret manager. `.env.example` contains placeholders only. If a real credential was pushed to Git, rotate it; deleting it from the latest file does not erase it from Git history.
- Terminate HTTPS at a trusted reverse proxy or load balancer in production and configure it to forward traffic to the application over a protected network.

## Docker

```bash
docker build -t order-management .
docker run --env-file .env -p 8080:8080 order-management
```

## Metrics

The service exposes a Prometheus-styled metrics endpoint at `/metrics` without requiring local Prometheus or Grafana. The endpoint returns text metrics like:

```text
http_requests_total{method="GET",path="/api/v1/orders",status="200"} 12
http_request_duration_seconds_sum{method="GET",path="/api/v1/orders"} 0.023123
http_errors_total 0
database_errors_total 0
```

Request counts and latency are tracked by method, route, and status. `http_errors_total` counts HTTP responses with status 400 or above; `database_errors_total` counts failed PostgreSQL operations. These in-process counters reset when the application restarts.

Each request is logged with its request ID, method, matched route, status, duration, and error (`-` on success). The same request ID is propagated in context and attached to trace logs as work passes through controller, service, repository, and PostgreSQL. For example:

```text
event=trace request_id="abc123" layer="controller" operation="create_order"
event=trace request_id="abc123" layer="service" operation="create_order"
event=trace request_id="abc123" layer="repository" operation="create_order"
event=trace request_id="abc123" layer="postgres" operation="insert_order"
request_id=abc123 method=POST path=/api/v1/orders status=201 duration=15ms error="-"
```

This is request-correlated application logging, not distributed tracing with spans or an OpenTelemetry backend.

## Performance and concurrency

The PostgreSQL repository uses a shared `pgxpool.Pool`; PostgreSQL statements use parameters, and each API operation issues only the queries required for that operation. The `orders.id` primary key supports single-order lookups and descending ID ordering for list requests. The schema also defines customer, status, and created-time indexes for filtering/reporting queries.

`go test ./...` includes a test that submits 100 concurrent order-create requests against the thread-safe in-memory repository and verifies all requests succeed with unique IDs. To check for data races, run `go test -race ./...` in an environment with cgo and a C compiler installed.

## Health checks

- `GET /health/live`
- `GET /health/ready`